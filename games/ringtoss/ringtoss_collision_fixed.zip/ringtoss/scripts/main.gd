extends Node3D

const RING_SCENE: PackedScene = preload("res://games/ringtoss/scenes/ring.tscn")

@export_file("*.json") var ruta_niveles_json: String = "res://games/ringtoss/data/niveles.json"
@export var escena_cono: PackedScene = preload("res://games/ringtoss/scenes/cone.tscn")
@export var nivel_actual: int = 1

# El GLB original del cono mide ~75x155x75 unidades, por eso se escala acá.
# Estos valores quedan exportados para que puedas ajustar la mesa sin tocar el JSON.
@export var origen_conos: Vector3 = Vector3(0.0, 0.775, -4.0)
@export var escala_cono: Vector3 = Vector3(0.0018, 0.0018, 0.0018)
@export var rotacion_y_conos: float = 0.0

@onready var camara: Camera3D = $Camera3D

@onready var ui_puntaje: UIPuntaje = $UI/Puntaje as UIPuntaje
@onready var ui_level_number: UILevelNumber = $UI/LevelNumber as UILevelNumber
@onready var ui_level_title: Label = $UI/LevelTitle
@onready var panel_resultados: PanelResultados = $UI/PanelResultados as PanelResultados

# Son restos de la escena base de Gold Can Alley. Se ocultan hasta que agreguemos el aro.
@onready var barra_energia: CanvasItem = get_node_or_null("UI/BarraEnergia") as CanvasItem
@onready var contenedor_lanzamientos_ui: CanvasItem = get_node_or_null("UI/ContenedorPelotasUI") as CanvasItem

var pos_inicial_camara: Vector3 = Vector3(0.0, 3.8, -3.8)
var rot_inicial_camara: Vector3 = Vector3(deg_to_rad(-85.0), 0.0, 0.0)
var pos_final_camara: Vector3 = Vector3(0.0, 1.443, -0.31)
var rot_final_camara: Vector3 = Vector3(deg_to_rad(-0.5), 0.0, 0.0)

var contenedor_conos: Node3D
var ctrl_resultados: ControladorResultados
var puntaje_nivel: int = 0
var puntaje_maximo_nivel: int = 0
var anillos_totales: int = 3
var anillos_lanzados: int = 0
var nivel_data: Dictionary = {}

# Si existe un Marker3D llamado RingSpawn lo usamos.
# Si no existe, el aro aparece en posicion_spawn_ring.
@onready var ring_spawn: Marker3D = get_node_or_null("RingSpawn") as Marker3D

@export var posicion_spawn_ring: Vector3 = Vector3(0.0, 1.0, -1.7)
@export var fuerza_minima_ring: float = 2.0
@export var fuerza_maxima_ring: float = 12.0
@export var multiplicador_fuerza_ring: float = 0.02
@export var impulso_vertical_ring: float = 0.7
@export var sensibilidad_horizontal_ring: float = 0.002
@export var swipe_minimo_ring: float = 20.0
@export var demora_siguiente_ring: float = 1.2

var current_ring: RigidBody3D = null
var drag_start: Vector2 = Vector2.ZERO
var dragging: bool = false
var ring_launched: bool = false


func _input(event: InputEvent) -> void:
	# Touch en Android/iOS.
	if event is InputEventScreenTouch:
		var touch: InputEventScreenTouch = event as InputEventScreenTouch
		_procesar_input_lanzamiento(touch.pressed, touch.position)
		return

	# Mouse para poder probar directamente desde el editor.
	if event is InputEventMouseButton:
		var mouse_event: InputEventMouseButton = event as InputEventMouseButton
		if mouse_event.button_index == MOUSE_BUTTON_LEFT:
			_procesar_input_lanzamiento(mouse_event.pressed, mouse_event.position)


func _procesar_input_lanzamiento(presionado: bool, posicion: Vector2) -> void:
	if presionado:
		if current_ring == null or ring_launched:
			return

		drag_start = posicion
		dragging = true
		return

	if not dragging:
		return

	dragging = false

	if current_ring == null or ring_launched:
		return

	var swipe: Vector2 = drag_start - posicion
	print("Ring Toss SWIPE: ", swipe, " | length=", swipe.length())
	lanzar_aro(swipe)


func lanzar_aro(swipe: Vector2) -> void:
	if current_ring == null or ring_launched:
		return

	var longitud_swipe: float = swipe.length()
	if longitud_swipe < swipe_minimo_ring:
		print("Ring Toss: swipe demasiado corto")
		return

	var fuerza: float = clampf(
		longitud_swipe * multiplicador_fuerza_ring,
		fuerza_minima_ring,
		fuerza_maxima_ring
	)

	var direccion: Vector3 = Vector3(
		swipe.x * sensibilidad_horizontal_ring,
		impulso_vertical_ring,
		-1.0
	).normalized()

	ring_launched = true
	current_ring.freeze = false
	current_ring.sleeping = false
	current_ring.apply_central_impulse(direccion * fuerza)
	current_ring.apply_torque_impulse(Vector3(8.0, 0.0, 0.0))

	print("Ring Toss RING LANZADO | fuerza=", fuerza, " | direccion=", direccion)

	await get_tree().create_timer(demora_siguiente_ring).timeout

	if is_inside_tree():
		_spawn_ring()
	
func _ready() -> void:
	contenedor_conos = Node3D.new()
	contenedor_conos.name = "ConosGenerados"
	add_child(contenedor_conos)

	ctrl_resultados = ControladorResultados.new()
	add_child(ctrl_resultados)
	var hud: Array = [ui_puntaje, ui_level_number]
	ctrl_resultados.configurar(panel_resultados, hud, ui_puntaje, ui_level_number, reiniciar_nivel)

	if barra_energia:
		barra_energia.visible = false
	if contenedor_lanzamientos_ui:
		contenedor_lanzamientos_ui.visible = false

	nivel_actual = max(1, save_manager.nivel_actual_seleccionado)
	cargar_nivel(nivel_actual)
	
	animar_camara_entrada()
	_spawn_ring()

func _spawn_ring() -> void:
	print("Ring Toss A PUNTO DE CREARSE ")

	# Si el aro anterior todavía estaba esperando ser lanzado, lo reemplazamos.
	# Si ya fue lanzado, lo dejamos en la escena para que pueda terminar de caer
	# y quedar enganchado en un cono.
	if current_ring != null and is_instance_valid(current_ring) and not ring_launched:
		current_ring.queue_free()

	current_ring = null

	var ring_instance: Node = RING_SCENE.instantiate()
	var ring_body: RigidBody3D = ring_instance as RigidBody3D

	if ring_body == null:
		ring_instance.queue_free()
		push_error("Ring Toss: el root de Ring.tscn debe ser un RigidBody3D")
		return

	# Primero hay que agregar el RigidBody3D al árbol y recién después
	# asignarle una posición/global_transform.
	add_child(ring_body)
	current_ring = ring_body

	current_ring.freeze = true
	current_ring.sleeping = false
	current_ring.linear_velocity = Vector3.ZERO
	current_ring.angular_velocity = Vector3.ZERO

	if ring_spawn != null:
		current_ring.global_transform = ring_spawn.global_transform
	else:
		current_ring.position = posicion_spawn_ring

	ring_launched = false
	dragging = false

	print("Ring Toss RING CREADO EN: ", current_ring.global_position)

func animar_camara_entrada() -> void:
	if barra_energia: barra_energia.visible = false
	if ui_puntaje: ui_puntaje.visible = false
	if ui_level_number: ui_level_number.visible = true

	var tween = create_tween().set_parallel(true)
	tween.tween_property(camara, "global_position", pos_final_camara, 2.0)\
		.set_trans(Tween.TRANS_CUBIC)\
		.set_ease(Tween.EASE_OUT)

	tween.tween_property(camara, "global_rotation", rot_final_camara, 2.0)\
		.set_trans(Tween.TRANS_CUBIC)\
		.set_ease(Tween.EASE_OUT)

	tween.chain().tween_callback(func():
		if barra_energia: barra_energia.visible = true
		if ui_puntaje: ui_puntaje.visible = true
		if ui_level_number: ui_level_number.visible = true
	)

func cargar_nivel(numero_nivel: int) -> void:
	ctrl_resultados.reset()
	limpiar_conos()

	nivel_actual = numero_nivel
	puntaje_nivel = 0
	puntaje_maximo_nivel = 0
	anillos_lanzados = 0
	nivel_data = {}
	actualizar_hud()

	if not FileAccess.file_exists(ruta_niveles_json):
		push_error("Ring Toss: no existe " + ruta_niveles_json)
		return

	var texto_json := FileAccess.get_file_as_string(ruta_niveles_json)
	var datos_parseados: Variant = JSON.parse_string(texto_json)

	if not (datos_parseados is Dictionary):
		push_error("Ring Toss: niveles.json no contiene un Dictionary válido")
		return

	var datos: Dictionary = datos_parseados as Dictionary
	var clave: String = str(numero_nivel)
	if not datos.has(clave):
		push_error("Ring Toss: no existe el nivel " + clave)
		return

	nivel_data = datos[clave] as Dictionary
	anillos_totales = int(nivel_data.get("rings", 3))
	puntaje_maximo_nivel = int(nivel_data.get("puntaje_maximo", 0))

	var separacion_x := float(nivel_data.get("separacion_x", 0.30))
	var separacion_z := float(nivel_data.get("separacion_z", 0.30))
	var conos: Array = nivel_data.get("cones", [])

	for cone_data in conos:
		crear_cono(cone_data, separacion_x, separacion_z)

	# Fallback: si el JSON no trae puntaje máximo, lo calculamos pensando
	# en que cada lanzamiento puede acertar el cono de mayor valor.
	if puntaje_maximo_nivel <= 0:
		var max_por_cono := 0
		for cone_data in conos:
			max_por_cono = max(max_por_cono, int(cone_data.get("points", 100)))
		puntaje_maximo_nivel = max_por_cono * anillos_totales

	actualizar_hud()
	anunciar_nivel(numero_nivel)

func crear_cono(cone_data: Dictionary, separacion_x: float, separacion_z: float) -> Node3D:
	if not escena_cono:
		return null

	var cono := escena_cono.instantiate() as Node3D
	if not cono:
		return null

	var grid_x := float(cone_data.get("x", 0.0))
	var grid_z := float(cone_data.get("z", 0.0))
	var escala_extra := float(cone_data.get("scale", 1.0))
	var rot_y := float(cone_data.get("rot_y", rotacion_y_conos))
	var puntos := int(cone_data.get("points", 100))
	var cone_id := str(cone_data.get("id", "cone"))

	contenedor_conos.add_child(cono)
	cono.position = origen_conos + Vector3(grid_x * separacion_x, 0.0, grid_z * separacion_z)
	cono.scale = escala_cono * escala_extra
	cono.rotation_degrees.y = rot_y

	# El futuro script del aro puede leer estos metadatos directamente.
	cono.set_meta("cone_id", cone_id)
	cono.set_meta("points", puntos)
	cono.set_meta("scored", false)

	return cono

func limpiar_conos() -> void:
	if not contenedor_conos:
		return
	for child in contenedor_conos.get_children():
		child.queue_free()

func actualizar_hud() -> void:
	if ctrl_resultados:
		ctrl_resultados.actualizar_puntaje(puntaje_nivel)
		ctrl_resultados.actualizar_nivel(nivel_actual)

func anunciar_nivel(numero_nivel: int) -> void:
	if not ui_level_title:
		return
	ui_level_title.text = game_manager.obtener_titulo_nivel(str(numero_nivel), "ringtoss")
	ui_level_title.modulate.a = 1.0
	ui_level_title.visible = true
	var tween := create_tween()
	tween.tween_interval(1.5)
	tween.tween_property(ui_level_title, "modulate:a", 0.0, 0.5)
	tween.tween_callback(func(): ui_level_title.visible = false)

# -----------------------------------------------------------------------------
# API lista para conectar el aro más adelante.
# Ejemplo desde el aro: main.registrar_lanzamiento(cono_que_emboco)
# Si no emboca:          main.registrar_lanzamiento(null)
# -----------------------------------------------------------------------------
func registrar_lanzamiento(cono: Node = null) -> void:
	if ctrl_resultados.esta_mostrado():
		return
	if anillos_lanzados >= anillos_totales:
		return

	anillos_lanzados += 1
	if cono and is_instance_valid(cono):
		var puntos := int(cono.get_meta("points", 100))
		puntaje_nivel += puntos
		actualizar_hud()
		if cono is Node3D:
			EfectosUI.crear_efecto_puntos((cono as Node3D).global_position, puntos)

	if anillos_lanzados >= anillos_totales:
		finalizar_nivel()

func finalizar_nivel() -> void:
	ctrl_resultados.mostrar(nivel_actual, puntaje_nivel, puntaje_maximo_nivel)

func reiniciar_nivel() -> void:
	cargar_nivel(nivel_actual)
